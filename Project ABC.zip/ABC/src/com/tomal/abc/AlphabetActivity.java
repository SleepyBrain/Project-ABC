package com.tomal.abc;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class AlphabetActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_alphabet);
	}
	
	public void btnA(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterA.class);
		startActivity(intent);
	}
	
	
	public void btnB(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterB.class);
		startActivity(intent);
	}
	
	public void btnC(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterC.class);
		startActivity(intent);
	}
	
	public void btnD(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterD.class);
		startActivity(intent);
	}
	
	public void btnE(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterE.class);
		startActivity(intent);
	}
	
	public void btnF(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterF.class);
		startActivity(intent);
	}
	
	public void btnG(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterG.class);
		startActivity(intent);
	}
	
	public void btnH(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterH.class);
		startActivity(intent);
	}
	
	public void btnI(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterI.class);
		startActivity(intent);
	}
	
	public void btnJ(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterJ.class);
		startActivity(intent);
	}
	
	public void btnK(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterK.class);
		startActivity(intent);
	}
	
	public void btnL(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterL.class);
		startActivity(intent);
	}
	
	public void btnM(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterM.class);
		startActivity(intent);
	}
	
	public void btnN(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterN.class);
		startActivity(intent);
	}
	
	public void btnO(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterO.class);
		startActivity(intent);
	}
	
	public void btnP(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterP.class);
		startActivity(intent);
	}
	
	public void btnQ(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterQ.class);
		startActivity(intent);
	}
	
	public void btnR(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterR.class);
		startActivity(intent);
	}
	
	public void btnS(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterS.class);
		startActivity(intent);
	}
	
	public void btnT(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterT.class);
		startActivity(intent);
	}
	
	
	public void btnU(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterU.class);
		startActivity(intent);
	}
	
	public void btnV(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterV.class);
		startActivity(intent);
	}
	
	public void btnW(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterW.class);
		startActivity(intent);
	}
	
	public void btnX(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterX.class);
		startActivity(intent);
	}
	

	public void btnY(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterY.class);
		startActivity(intent);
	}
	
	public void btnZ(View v) {
		Intent intent=new Intent(AlphabetActivity.this, LetterZ.class);
		startActivity(intent);
	}
	
	

}
