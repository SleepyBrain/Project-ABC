/** Automatically generated file. DO NOT MODIFY */
package com.tomal.abc;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}